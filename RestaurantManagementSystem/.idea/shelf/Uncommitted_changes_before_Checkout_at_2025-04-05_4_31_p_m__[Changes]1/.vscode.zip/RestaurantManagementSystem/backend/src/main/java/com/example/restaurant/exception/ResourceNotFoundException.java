package com.example.restaurant.exception;

public class ResourceNotFoundException {
    
}
