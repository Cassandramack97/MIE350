package com.example.restaurant.service;

public class DashboardService {
    
}
