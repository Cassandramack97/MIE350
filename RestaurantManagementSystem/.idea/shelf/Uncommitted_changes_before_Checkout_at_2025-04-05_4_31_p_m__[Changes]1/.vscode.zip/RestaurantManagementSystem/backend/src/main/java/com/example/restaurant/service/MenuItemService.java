package com.example.restaurant.service;

public class MenuItemService {
    
}
