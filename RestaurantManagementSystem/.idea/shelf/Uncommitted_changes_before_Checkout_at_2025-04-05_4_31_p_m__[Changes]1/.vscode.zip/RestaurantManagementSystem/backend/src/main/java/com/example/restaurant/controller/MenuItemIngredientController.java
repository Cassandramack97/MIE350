package com.example.restaurant.controller;

public class MenuItemIngredientController {

}
